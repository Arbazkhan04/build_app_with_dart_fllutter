import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SettingScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return SettingState();
  }

}

class SettingState extends State{
  bool check = false;
  int r = 0;
  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      color: Colors.green.shade300,
      child: Column(
        children: [
          if(!check) ElevatedButton(onPressed: () => generateNumber(), child: Text("Generate Random Number")),
          SizedBox(height: 22,),
          Text("Random Number = $r ......" , style: TextStyle(fontSize: 22),),
          SizedBox(height: 22,),
          check ? Text("Limit Reached  ......" , style: TextStyle(fontSize: 22),) : Text("Limit Available  ......" , style: TextStyle(fontSize: 22),)
        ],
      )
    );
  }

  generateNumber(){
    int num = Random().nextInt(101);
    setState(() {
      // if(!check)
      //   r = r + num;
      if(r > 1000)
        check = true;
    });

  }

}