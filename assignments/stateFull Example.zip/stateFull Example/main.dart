import 'package:flutter/material.dart';
import 'package:sub_pages/home_screen.dart';

void main() {
  runApp(MaterialApp(
    home: HomeScreen(),
  ));
}
