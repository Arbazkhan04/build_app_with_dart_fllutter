import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DraftScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return DraftState();
  }

}

class DraftState extends State{

  Color c = Colors.white;

  List<Color> myColors = [Colors.red , Colors.green , Colors.grey , Colors.orange , Colors.blue];
  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      color: Colors.red.shade300,
      child: Column(
        children: [
          InkWell(
            child: Text("Generate Random Color ......" , style: TextStyle(fontSize: 22),),
            onTap: () => changeColor(),
          ),
          SizedBox(height: 22,),
          Container(height: 100 , width: 100, color: c,)

        ],
      )
    );
  }

  changeColor(){
    setState(() {
      int index = Random().nextInt(myColors.length);
      c = myColors[index];
    });
  }

}