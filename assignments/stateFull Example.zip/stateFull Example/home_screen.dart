import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sub_pages/draft_screen.dart';
import 'package:sub_pages/profile_screen.dart';
import 'package:sub_pages/setting_screen.dart';

class HomeScreen extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return HomeState();
  }
}

class HomeState extends State{
  List<Widget> screens = [SettingScreen() , DraftScreen() , ProfileScreen()];
  List<String> msgs = ["Settings" , "Drafts" , "Profile"];
  int index = 0;
  String msg = "";

  void bottomTap(int i){
    setState((){
      index = i;
      msg = msgs[index];
    });
  }

  setPage(int i){
    setState(() {
      index = i;
    });
  }

  @override
  Widget build(BuildContext context) {
    msg = msgs[index];
    return Scaffold(
      body: screens[index],
      appBar: AppBar(
        actions: [
          IconButton(onPressed: () => setPage(0), icon: Icon(Icons.settings)),
          IconButton(onPressed: () => setPage(2), icon: Icon(Icons.person))
        ],
        backgroundColor: Colors.orange,
      ),
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Colors.black,
        unselectedItemColor: Colors.white,
        currentIndex: index,
        backgroundColor: Colors.orange,
        onTap: (int i)=> bottomTap(i),
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.settings) , label: "Settings"),
          BottomNavigationBarItem(icon: Icon(Icons.drafts) , label: "Draft"),
          BottomNavigationBarItem(icon: Icon(Icons.person) , label: "Profile"),
        ],
      ),
    );
  }

}