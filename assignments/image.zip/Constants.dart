class Constants{
  static final String IMG_ONE = "assets/images/one.jpg";
  static final String IMG_TWO = "assets/images/two.jpg";
  static final String IMG_THREE = "assets/images/three.jpg";
  static final String IMG_FOUR = "assets/images/four.jpg";
  static final String WIFI_ON = "assets/images/on.png";
  static final String WIFI_OFF = "assets/images/off.jpg";
}