import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:images/utils/Constants.dart';

class HomeScreen extends StatefulWidget{
  // @override
  // State<StatefulWidget> createState() {
      // return HomeState(
  // }

  HomeState createState ()=> HomeState();

}

class HomeState extends State{
  String one = Constants.IMG_ONE;
  String two = Constants.IMG_FOUR;
  String wifi = Constants.WIFI_ON;
  bool wifiSwitch = true;
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey,
        title: Text("Images"),
      ),
      body: SingleChildScrollView(
        child: Container(
          alignment: Alignment.center,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              InkWell(child : Padding(padding: EdgeInsets.all(20),
                  child: Image.asset(one , width: width/2, height: width/3, fit: BoxFit.cover,))
                , onTap: ()=> changeOne(),),
              InkWell( child : Padding(padding: EdgeInsets.all(20),
                  child: Image.asset(two , width: width/2, height: width/3, fit: BoxFit.cover,))
                , onTap: ()=> changeTwo(),),

              InkWell( child : Padding(padding: EdgeInsets.all(20),
                  child: Image.asset(wifi , width: width/2, height: width/3, fit: BoxFit.cover,))
                , onTap: ()=> switchImg(),),
              if(wifiSwitch)  Text("Wifi On"),

              InkWell( child : Padding(padding: EdgeInsets.all(20),
                  child: Image.asset(wifi , width: width/2, height: width/3, fit: BoxFit.cover,))
                , onTap: ()=> switchImg(),),

              ElevatedButton(onPressed: ()=>switchImg, child: Text("Random image"))
            ],
          ),
        ),
      ),
    );

  }

  switchImg(){
    setState(() {
      if(wifiSwitch)
        wifi = Constants.WIFI_OFF;
      else
        wifi = Constants.WIFI_ON;

      wifiSwitch = !wifiSwitch;
    });
  }

  changeOne(){
    setState(() {
      one = Constants.IMG_TWO;
    });
  }

  changeTwo(){
    setState(() {
      two = Constants.IMG_THREE;
    });

  }

}